/*
 * global.h
 *
 *  Created on: Mar 30, 2018
 *      Author: Kang Usman
 */

#ifndef GLOBAL_H_
#define GLOBAL_H_

#include "main.h"
#include "stm32f2xx_hal.h"
#include "fatfs.h"
#include "sdio.h"
#include "spi.h"
#include "usart.h"
#include "gpio.h"

#include "tim.h"
#include "jpeglib.h"

#include <stdio.h>
#include <setjmp.h>
#include <math.h>



#include "mp3.h"
#include "Karedox_VS1053Drv.h"
#include "fonts.h"
#include "lcd.h"
#include "avi.h"
#include "mjpeg.h"
#include "malloc.h"
#include "videoplayer.h"




#endif /* GLOBAL_H_ */
