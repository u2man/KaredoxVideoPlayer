/*
 * videoplayer.h
 *
 *  Created on: Mar 31, 2018
 *      Author: Kang Usman
 */

#ifndef VIDEOPLAYER_H_
#define VIDEOPLAYER_H_

#define AVI_AUDIO_BUF_SIZE    1024*5
#define AVI_VIDEO_BUF_SIZE    1024*60

extern uint16_t frame;
extern __IO uint8_t frameup;


void video_play(void);
uint8_t video_play_mjpeg(uint8_t *pname);
void video_time_show(FIL *favi,AVI_INFO *aviinfo);


#endif /* VIDEOPLAYER_H_ */
