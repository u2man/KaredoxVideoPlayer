/*
 * Karedox_VS1053Drv.c
 *
 *  Created on: Oct 15, 2015
 *      Author: Kang Usman
 */


#include "Karedox_VS1053Drv.h"



void SPI_Byte_Transfer(uint8_t thebyte);
uint8_t SPI_Byte_Read(void);
void Reset_Delay(uint32_t thedelay);

const uint16_t chipNumber[16] = {
  1001, 1011, 1011, 1003, 1053, 1033, 1063, 1103,
  0, 0, 0, 0, 0, 0, 0, 0
};

void Karedox_VS1053_SineWaveTest(void){

	uint8_t sinewavedata[8]={0x53, 0xEF, 0x6E, 0xFA, 0x00, 0x00, 0x00, 0x00};

	Karedox_VS1053_SCI_Write(SCI_MODE, 0x0820);

	Karedox_VS1053_SDI_Write(sinewavedata,8);



}

uint16_t Karedox_VS1053_TestInitSoftware(void){
	uint16_t ssVer;//,cmd_data;
	uint16_t MP3Mode;
	//uint16_t i;


  /* Start initialization with a dummy read, which makes sure our
     microcontoller chips selects and everything are where they
     are supposed to be and that VS10xx's SCI bus is in a known state. */
	//printf("There is something wrong with VS10xx\r\n");
     MP3Mode=Karedox_VS1053_SCI_Read(SCI_MODE);
     printf("debug1 %d\r\n",MP3Mode);
     if(MP3Mode != (SM_LINE1 | SM_SDINEW)) return 4;

     Karedox_VS1053_SCI_Write(SCI_CLOCKF, 0X9800);


     Karedox_VS1053_SCI_Write(SCI_VOL, 0x1010);


     /* Now it's time to load the proper patch set. */
     //LoadPlugin(plugin, sizeof(plugin)/sizeof(plugin[0]));
     //Karedox_VS1053_IO_Init(SPI_BaudRatePrescaler_32,0);

     //return 0;



  /* First real operation is a software reset. After the software
     reset we know what the status of the IC is. You need, depending
     on your application, either set or not set SM_SDISHARE. See the
     Datasheet for details. */
  Karedox_VS1053_SCI_Write(SCI_MODE,SM_SDINEW|SM_TESTS|SM_RESET);
  //printf("There is something wrong with VS10xx\n");
  HAL_Delay(1);

  /* A quick sanity check: write to two registers, then test if we
     get the same results. Note that if you use a too high SPI
     speed, the MSB is the most likely to fail when read again. */
  Karedox_VS1053_SCI_Write(SCI_HDAT0, 0xABAD);
  Karedox_VS1053_SCI_Write(SCI_HDAT1, 0x1DEA);


  if (Karedox_VS1053_SCI_Read(SCI_HDAT0) != 0xABAD || Karedox_VS1053_SCI_Read(SCI_HDAT1) != 0x1DEA) {
    printf("There is something wrong with VS10xx\r\n");
   // return 1;
  }

  /* Check VS10xx type */
   ssVer = ((Karedox_VS1053_SCI_Read(SCI_STATUS) >> 4) & 15);
   if (chipNumber[ssVer]) {
     printf("Chip is VS\r\n");//%d\n", chipNumber[ssVer]);
     if (chipNumber[ssVer] != 1053) {
       printf("Incorrect chip\n");
      return 1;
     }
   } else {
     printf("Unknown VS10xx SCI_MODE field SS_VER = \r\n");//, ssVer);
     return 1;
   }

   /* Set the clock. Until this point we need to run SPI slow so that
      we do not exceed the maximum speeds mentioned in
      Chapter SPI Timing Diagram in the Datasheet. */
  // Karedox_VS1053_SCI_Write(SCI_CLOCKF,
    //        HZ_TO_SC_FREQ(12288000) | SC_MULT_53_35X | SC_ADD_53_10X);
            //HZ_TO_SC_FREQ(12288000) | SC_MULT_53_50X | SC_ADD_53_20X);
	 Karedox_VS1053_SCI_Write(SCI_MODE, 0x0804);
   Karedox_VS1053_SCI_Write(SCI_CLOCKF, 0X8800);

   /* Now when we have upped the VS10xx clock speed, the microcontroller
      SPI bus can run faster. Do that before you start playing or
      recording files. */

   /* Set up other parameters. */
   //WriteVS10xxMem(PAR_CONFIG1, PAR_CONFIG1_AAC_SBR_SELECTIVE_UPSAMPLE);

   /* Set volume level at -6 dB of maximum */
   Karedox_VS1053_SCI_Write(SCI_VOL, 0x6969);

   //Bass
   Karedox_VS1053_SCI_Write(SCI_BASS,0);
   Karedox_VS1053_SDI_Write(0,1);
   Karedox_VS1053_SDI_Write(0,1);

   //Load Patch
   //for (i=0;i<3189;i++) {
  	 //Karedox_VS1053_SCI_Write(atab[i], dtab[i]);
  // }


   HAL_Delay(100);


   /* Now it's time to load the proper patch set. */
   //LoadPlugin(plugin, sizeof(plugin)/sizeof(plugin[0]));
   //Karedox_VS1053_IO_Init(SPI_BaudRatePrescaler_32,0);
   /* We're ready to go. */
   return 0;

}

void Karedox_VS1053_Init(void){

	uint16_t tmp;

	Karedox_VS1053_IO_Init(SPI_BAUDRATEPRESCALER_256,1);
	VS1053_DCS(1);
	VS1053_XCS(1);
	VS1053_RST(1);
    HAL_Delay(50);
	VS1053_RST(0);
    HAL_Delay(50);
	VS1053_RST(1);

	//Software Reset
	printf("Software Reset\r\n");
	Karedox_VS1053_SCI_Write(SCI_MODE,SM_RESET);
	HAL_Delay(1);

	//Wait for DREQ pin
	//printf("Wait DREQ\r\n");
	while (!VS1053_DREQ);


	Karedox_VS1053_SCI_Write(SCI_MODE,SM_SDINEW|SM_TESTS);
	Karedox_VS1053_SCI_Write(SCI_CLOCKF, 0X9000);

	tmp=Karedox_VS1053_SCI_Read(SCI_CLOCKF);

	if(tmp==0x9000){
		printf("SCI_CLOCKF OK\r\n");
		Karedox_VS1053_IO_Init(SPI_BAUDRATEPRESCALER_64,0);
	}

	Karedox_VS1053_SetVolume(0x1A1A);
	Karedox_VS1053_SCI_Write(SCI_BASS,0x7AFF);

	//Send 0
	Karedox_VS1053_SDI_Write(0,1);
	Karedox_VS1053_SDI_Write(0,1);

}

void MP3_Test_Song(void){

	FIL mp3File;
	FRESULT res;
	uint16_t dataread;
	uint8_t mp3DataBuffer[1024];
     printf("Test Play\r\n");
    res =f_open(&mp3File,"Music/juragan empang.mp3", FA_READ);
	//res =f_open(&mp3File,"Music/SikAsik.mp3", FA_READ);
	if(res==FR_OK){
		printf("Open FIle OK\r\n");
		while(!f_eof(&mp3File)){
        res=f_read(&mp3File,mp3DataBuffer,1024,(void *)&dataread);
         if((res==FR_OK)&&(dataread>0)){
       	  //afterplay=1;
       	  //printf("Send MP3 Data %d\r\n", dataread);
       	  Karedox_VS1053_SDI_Write(mp3DataBuffer,dataread);
       	  //dataread=Karedox_VS1053_Get_Decode_Time();

       	  }

       	  //}

         }
	}



	printf("res %d\r\n",res);



}

void Karedox_VS1053_IO_Init(uint16_t spi_prescaler,uint8_t spipol){
	  hspi3.Instance = SPI3;
	  hspi3.Init.Mode = SPI_MODE_MASTER;
	  hspi3.Init.Direction = SPI_DIRECTION_2LINES;
	  hspi3.Init.DataSize = SPI_DATASIZE_8BIT;
	  hspi3.Init.CLKPolarity = SPI_POLARITY_LOW;

		if(spipol){
			hspi3.Init.CLKPhase = SPI_PHASE_2EDGE;
		}
		else{
			hspi3.Init.CLKPhase = SPI_PHASE_1EDGE;
		}

	  //hspi3.Init.CLKPhase = SPI_PHASE_2EDGE;
	  hspi3.Init.NSS = SPI_NSS_SOFT;
	  hspi3.Init.BaudRatePrescaler =  spi_prescaler;// SPI_BAUDRATEPRESCALER_32;
	  hspi3.Init.FirstBit = SPI_FIRSTBIT_MSB;
	  hspi3.Init.TIMode = SPI_TIMODE_DISABLE;
	  hspi3.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
	  hspi3.Init.CRCPolynomial = 10;
	  if (HAL_SPI_Init(&hspi3) != HAL_OK)
	  {
	    _Error_Handler(__FILE__, __LINE__);
	  }
}

void Karedox_VS1053_SetVolume(uint16_t vol){
	Karedox_VS1053_SCI_Write(SCI_VOL,vol);
}

void Karedox_VS1053_SCI_Write(uint8_t sci_address, uint16_t sci_data){
     uint32_t timeout;

     timeout=0;
	//printf("Wait DREQ\r\n");
	while (!VS1053_DREQ){
		if (timeout++>100){
			printf("VS1053 Timeout\r\n");
			return;
		}
		HAL_Delay(1);
	}
	//printf("Wait DREQ...OK\r\n");
	VS1053_XCS(0);

	SPI_Byte_Transfer(SCI_WRITE);
	SPI_Byte_Transfer(sci_address);
	SPI_Byte_Transfer((uint8_t) (sci_data >> 8));
	SPI_Byte_Transfer((uint8_t)(sci_data & 0xFF));

	VS1053_XCS(1);

}

void Karedox_VS1053_SendEndFillByte(uint16_t count){
	uint16_t i, endfillbyte;

	endfillbyte=Karedox_VS1053_ReadWRAM(PAR_END_FILL_BYTE);

	for(i=0;i<count;i++){
		Karedox_VS1053_SDI_Write((uint8_t)endfillbyte,1);

	}
}

uint16_t Karedox_VS1053_ReadWRAM(uint16_t addressbyte){
	uint16_t tmp1, tmp2;

	Karedox_VS1053_SCI_Write(SCI_WRAMADDR,addressbyte);
	tmp1=Karedox_VS1053_SCI_Read(SCI_WRAM);

	Karedox_VS1053_SCI_Write(SCI_WRAMADDR,addressbyte);
	tmp2=Karedox_VS1053_SCI_Read(SCI_WRAM);

	if(tmp1==tmp2)
		return tmp1;

	Karedox_VS1053_SCI_Write(SCI_WRAMADDR,addressbyte);
	tmp2=Karedox_VS1053_SCI_Read(SCI_WRAM);

	if(tmp1==tmp2)
		return tmp1;

	Karedox_VS1053_SCI_Write(SCI_WRAMADDR,addressbyte);
	tmp2=Karedox_VS1053_SCI_Read(SCI_WRAM);

	if(tmp1==tmp2)
		return tmp1;


}

uint16_t Karedox_VS1053_SCI_Read(uint8_t sci_address){
  uint16_t temp;

  while (!VS1053_DREQ); //Wait until DREQ is high

  VS1053_XCS(0);

  SPI_Byte_Transfer(SCI_READ);
  SPI_Byte_Transfer(sci_address);
  temp = (uint16_t) SPI_Byte_Read() << 8;
  temp |= SPI_Byte_Read();

  VS1053_XCS(1);

  return temp;
}

uint16_t Karedox_VS1053_SDI_Write(uint8_t *sdi_data, uint16_t datasize){

	uint16_t i;

	//if(datasize>32)
		//return 0;

	
		 //}
  // printf("SDI Write\n");

	VS1053_DCS(0);
	for(i=0;i<datasize;i++){
		//while (!VS1053_DREQ);
    while (!VS1053_DREQ){

    }
		SPI_Byte_Transfer(*sdi_data++);

	}
	VS1053_DCS(1);


	return 1;
}

uint16_t Karedox_VS1053_Get_Decode_Time(void){
	return (Karedox_VS1053_SCI_Read(SCI_DECODE_TIME));
}

void Karedox_VS1053_LoadPlugin(const uint16_t *d, uint16_t len){
	  int i = 0;

	  while (i<len) {
	    unsigned short addr, n, val;
	    addr = d[i++];
	    n = d[i++];
	    if (n & 0x8000U) { /* RLE run, replicate n samples */
	      n &= 0x7FFF;
	      val = d[i++];
	      while (n--) {
	        Karedox_VS1053_SCI_Write(addr, val);
	      }
	    } else {           /* Copy run, copy n samples */
	      while (n--) {
	        val = d[i++];
	        Karedox_VS1053_SCI_Write(addr, val);
	      }
	    }
	  }
}

void SPI_Byte_Transfer(uint8_t thebyte){

  /* Wait for SPI1 Tx buffer empty */
	HAL_SPI_Transmit(&hspi3,&thebyte,1,1000);
//  while (SPI_I2S_GetFlagStatus(SPI1, SPI_I2S_FLAG_TXE) == RESET);
//  /* Send SPI1 data */
//  SPI_I2S_SendData(SPI1,thebyte);
//  /* Wait for SPI1 data reception */
//  while (SPI_I2S_GetFlagStatus(SPI1, SPI_I2S_FLAG_RXNE) == RESET);
//  /* Read SPI1 received data */
//  SPI_I2S_ReceiveData(SPI1);

}

uint8_t SPI_Byte_Read(void){
 uint8_t temp;

  HAL_SPI_Receive(&hspi3,&temp,1,1000);
// /* Wait for SPI1 Tx buffer empty */
//  while (SPI_I2S_GetFlagStatus(SPI1, SPI_I2S_FLAG_TXE) == RESET);
// /* Send SPI1 data */
//  SPI_I2S_SendData(SPI1,0x0000);
// /* Wait for SPI1 data reception */
//  while (SPI_I2S_GetFlagStatus(SPI1, SPI_I2S_FLAG_RXNE) == RESET);
//  /* Read SPI1 received data */
//  temp=SPI_I2S_ReceiveData(SPI1);

  return temp;

}

void Reset_Delay(uint32_t thedelay){

	while(thedelay--){

	}
}
