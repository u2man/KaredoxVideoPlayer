/*
 * lcd.c
 *
 *  Created on: Mar 31, 2018
 *      Author: Kang Usman
 */

#include "global.h"

static sFONT *LCD_Currentfonts;
__IO uint16_t TextColor = 0x0000, BackColor = 0xFFFF;

void lcd_init(void){

	uint32_t lcdid=0;

	//Turn On LCD Backlight
	HAL_GPIO_WritePin(LCD_BL_GPIO_Port, LCD_BL_Pin, GPIO_PIN_SET);

	//LCD Reset
	HAL_GPIO_WritePin(LCD_RST_GPIO_Port, LCD_RST_Pin, GPIO_PIN_SET);
	HAL_Delay(2);
	HAL_GPIO_WritePin(LCD_RST_GPIO_Port, LCD_RST_Pin, GPIO_PIN_RESET);
	HAL_Delay(2);
	HAL_GPIO_WritePin(LCD_RST_GPIO_Port, LCD_RST_Pin, GPIO_PIN_SET);

	HAL_Delay(50);

	lcdid = lcd_readReg(0x00);

	printf("LCD ID %lu\r\n",lcdid);

	if(lcdid==0x8989){
		printf("LCD Detected\r\n");

		LCD_WriteReg(0x0000,0x0001);
	    LCD_WriteReg(0x0003,0xA0A8);
	    LCD_WriteReg(0x000C,0x0000);
	    LCD_WriteReg(0x000D,0x000F);
	    LCD_WriteReg(0x000E,0x2B00);
	    LCD_WriteReg(0x001E,0x00B8);
	    LCD_WriteReg(0x0001,0x3B3F); // 0x2B3F
	    LCD_WriteReg(0x0002,0x0600);
	    LCD_WriteReg(0x0010,0x0000);
	    LCD_WriteReg(0x0011,0x6018); // Up-Right	AM:Vertical　0x6068
	    LCD_WriteReg(0x0005,0x0000);
	    LCD_WriteReg(0x0006,0x0000);
	    LCD_WriteReg(0x0016,0xEF1C);
	    LCD_WriteReg(0x0017,0x0003);
	    LCD_WriteReg(0x0007,0x0233);
	    LCD_WriteReg(0x000B,0x0000);
	    LCD_WriteReg(0x000F,0x0000);
	    LCD_WriteReg(0x0041,0x0000);
	    LCD_WriteReg(0x0042,0x0000);
	    LCD_WriteReg(0x0048,0x0000);
	    LCD_WriteReg(0x0049,0x013F);
	    LCD_WriteReg(0x004A,0x0000);
	    LCD_WriteReg(0x004B,0x0000);
	    LCD_WriteReg(0x0044,0xEF00);
	    LCD_WriteReg(0x0045,0x0000);
	    LCD_WriteReg(0x0046,0x013F);
	    LCD_WriteReg(0x0030,0x0707);
	    LCD_WriteReg(0x0031,0x0204);
	    LCD_WriteReg(0x0032,0x0204);
	    LCD_WriteReg(0x0033,0x0502);
	    LCD_WriteReg(0x0034,0x0507);
	    LCD_WriteReg(0x0035,0x0204);
	    LCD_WriteReg(0x0036,0x0204);
	    LCD_WriteReg(0x0037,0x0502);
	    LCD_WriteReg(0x003A,0x0302);
	    LCD_WriteReg(0x003B,0x0302);
	    LCD_WriteReg(0x0023,0x0000);
	    LCD_WriteReg(0x0024,0x0000);
	    LCD_WriteReg(0x0025,0x8000);
	    LCD_WriteReg(0x004e,0);
	    LCD_WriteReg(0x004f,0);

	    LCD_SetFont(&LCD_DEFAULT_FONT);
	    LCD_Clear(LCD_COLOR_BLACK);

	}
	else{
		printf("No LCD\r\n");
	}



}

void LCD_SetColors(__IO uint16_t _TextColor, __IO uint16_t _BackColor){
	  TextColor = _TextColor;
	  BackColor = _BackColor;

}

void LCD_GetColors(uint16_t *_TextColor, uint16_t *_BackColor){

}

void LCD_SetTextColor(__IO uint16_t Color){

}

void LCD_SetBackColor(__IO uint16_t Color){

}

void LCD_ClearLine(uint16_t Line){

}

void LCD_Clear(uint16_t Color){
	  uint32_t index = 0;

	  LCD_SetCursor(0x00, 0x013F);
	  LCD_WriteRAM_Prepare(); /* Prepare to write GRAM */
	  for(index = 0; index < 76800; index++)
	  {
	    LCD_RAM = Color;
	    //Delay_ms(5);
	  }

}

void LCD_SetCursor(uint16_t Xpos, uint16_t Ypos){
	  LCD_WriteReg(LCD_REG_78,Xpos); /* Row */
	  LCD_WriteReg(LCD_REG_79,Ypos); /* Line */

}

void LCD_DrawChar(uint16_t Xpos, uint16_t Ypos, const uint16_t *c){

}

void LCD_DisplayChar(uint16_t Line, uint16_t Column, uint8_t Ascii){

}

void LCD_SetFont(sFONT *fonts){

}

sFONT *LCD_GetFont(void){

}

void LCD_DisplayStringLine(uint16_t Line, uint8_t *ptr){

	printf("%s\r\n",ptr);

}

void LCD_SetDisplayWindow(uint16_t Xpos, uint16_t Ypos, uint16_t Height, uint16_t Width){
	uint16_t buffer1, buffer2;
	uint16_t xstart, xend, ystart, yend;
	uint16_t a,b,c,d;

	//x=Xpos;
	//y=Ypos;

	LCD_WriteReg(LCD_REG_68, (Height - 1 + Ypos) << 8 | Ypos);
	LCD_WriteReg(LCD_REG_69, LCD_PIXEL_WIDTH - Width - Xpos);
	LCD_WriteReg(LCD_REG_70, LCD_PIXEL_WIDTH - 1 - Xpos);

	  return;



	//a=


	//xstart=x;//- Height;
	//xend= x+Height;
	//ystart=319-(y+Width);
	//yend=319-y;

	//Fill X Address
	buffer1 = xend;
	buffer1 = buffer1 << 8 | xstart;

	LCD_WriteReg(LCD_REG_68, buffer1);
	LCD_WriteReg(LCD_REG_69, ystart);
	LCD_WriteReg(LCD_REG_70, yend);

}

void LCD_WindowModeDisable(void){

}

void LCD_DrawLine(uint16_t Xpos, uint16_t Ypos, uint16_t Length, uint8_t Direction){

}

void LCD_DrawLineX(int x1, int y1, int x2, int y2,uint16_t bkColor){

}

void LCD_DrawRect(uint16_t Xpos, uint16_t Ypos, uint8_t Height, uint16_t Width){

}

void LCD_DrawCircle(uint16_t Xpos, uint16_t Ypos, uint16_t Radius){

}

void LCD_DrawMonoPict(const uint32_t *Pict){

}

void LCD_WriteBMP(uint32_t BmpAddress){

}

void LCD_DrawUniLine(uint16_t x1, uint16_t y1, uint16_t x2, uint16_t y2){

}

void LCD_DrawFullRect(uint16_t Xpos, uint16_t Ypos, uint16_t Width, uint16_t Height,uint16_t color){

}

void LCD_DrawFullCircle(uint16_t Xpos, uint16_t Ypos, uint16_t Radius){

}

void LCD_PolyLine(pPoint Points, uint16_t PointCount){

}

void LCD_PolyLineRelative(pPoint Points, uint16_t PointCount){

}

void LCD_ClosedPolyLine(pPoint Points, uint16_t PointCount){

}

void LCD_ClosedPolyLineRelative(pPoint Points, uint16_t PointCount){

}

void LCD_FillPolyLine(pPoint Points, uint16_t PointCount){

}

void LCD_SetPoint(uint16_t Xpos,uint16_t Ypos,uint16_t point){

}

void LCD_Mode(uint8_t mode){

}

void LCD_Draw_Wallpaper(const uint16_t *d){

}

void LCD_Draw_Icon(int startPosX, int startPosY, int width, int height, const uint16_t *d, uint8_t a){

}

void LCD_Text_xy(uint16_t xpos, uint16_t ypos, uint8_t *text, uint16_t textcolor){

}

void LCD_Draw_BinFile(uint8_t *filename,uint16_t xpos, uint16_t ypos, uint16_t imagewidth, uint16_t imageheight, uint8_t transparent){

}

void LCD_Draw_WallPaper_BinFIle(uint8_t *filename){

}

uint16_t RGB888_To_RGB565(uint8_t r, uint8_t g, uint8_t b){

}

void LCD_WriteRAM_Prepare(void){
	LCD_REG = LCD_REG_34;
}

void LCD_WriteRAM(uint16_t RGB_Code){
  /* Write 16-bit GRAM Reg */
  LCD_RAM = RGB_Code;

}

uint16_t LCD_ReadRAM(void){
  /* Write 16-bit Index (then Read Reg) */
  LCD_REG = LCD_REG_34; /* Select GRAM Reg */
  /* Read 16-bit Reg */
  return LCD_RAM;

}

void LCD_WriteReg(uint8_t LCD_Reg, uint16_t LCD_RegValue){

	LCD_REG = LCD_Reg;
	LCD_RAM = LCD_RegValue;

}

uint16_t lcd_readReg(uint8_t LCD_Reg){
	LCD_REG = LCD_Reg;

	return (LCD_RAM);
}

