/*
 * videoplayer.c
 *
 *  Created on: Mar 31, 2018
 *      Author: Kang Usman
 */

#include "global.h"

uint16_t frame;
__IO uint8_t frameup;
uint32_t playingtime,totalplay;
//uint8_t *audiobuf;//[]
//[AVI_VIDEO_BUF_SIZE];



void video_play(void){
//	uint8_t res;
// 	DIR vdir;
//	FILINFO vfileinfo;
//	uint8_t *fn;
//	uint8_t *pname;
//	uint16_t totavinum;
//	uint16_t curindex;
//	uint8_t key;
// 	uint16_t temp;
//	uint16_t *vindextbl;
//  uint8_t buf[32];

	//video_play_mjpeg("car1.avi");
	//video_play_mjpeg("skill.avi");

	//video_play_mjpeg((uint8_t*)"video/Hari Merdeka.avi");
	printf("play 8fps\r\n");
	video_play_mjpeg((uint8_t*)"video/COFFIN DANCE MEME.avi");
	return;
	LCD_Clear(LCD_COLOR_BLUE);
	HAL_Delay(1000);

	printf("play 12fps\r\n");
	video_play_mjpeg((uint8_t*)"video/infinitywar1.avi");
	LCD_Clear(LCD_COLOR_BLUE);
	HAL_Delay(1000);
	printf("play 8fps\r\n");
	video_play_mjpeg((uint8_t*)"video/infinitywar11.avi");
	LCD_Clear(LCD_COLOR_BLUE);
	HAL_Delay(1000);

	printf("play 8fps\r\n");
	video_play_mjpeg((uint8_t*)"video/darahmuda.avi");
	LCD_Clear(LCD_COLOR_BLUE);
	HAL_Delay(1000);


	video_play_mjpeg((uint8_t*)"video/Kembang Cinta.avi");
	LCD_Clear(LCD_COLOR_BLUE);
	HAL_Delay(1000);
//
//	video_play_mjpeg((uint8_t*)"video/Hellow Cinta.avi");
//	LCD_Clear(LCD_COLOR_BLUE);
//	HAL_Delay(1000);
//
//	video_play_mjpeg((uint8_t*)"video/Aduh Manis.avi");
//	LCD_Clear(LCD_COLOR_BLUE);
//	HAL_Delay(1000);
//
//	video_play_mjpeg((uint8_t*)"video/Cadas Pangeran.avi");
//	LCD_Clear(LCD_COLOR_BLUE);
//	HAL_Delay(1000);
//
//	video_play_mjpeg((uint8_t*)"video/Dulang Kuring.avi");
//	LCD_Clear(LCD_COLOR_BLUE);
//	HAL_Delay(1000);
//
//	video_play_mjpeg((uint8_t*)"video/Kahayang Keukeuh.avi");
//	LCD_Clear(LCD_COLOR_BLUE);
//	HAL_Delay(1000);
//
//	video_play_mjpeg((uint8_t*)"video/Sancang.avi");
//	LCD_Clear(LCD_COLOR_BLUE);
//	HAL_Delay(1000);
//

	totalplay=HAL_GetTick()-playingtime;
	LCD_Clear(LCD_COLOR_BLACK);
	//sprintf((char*)buf,"Play time %lu",totalplay);
	//LCD_DisplayStringLine(Line0,buf);
}

uint8_t video_play_mjpeg(uint8_t *pname){
	//[AVI_VIDEO_BUF_SIZE];

	FIL *favi;
	uint8_t  res=0;
	uint16_t offset=0;
	uint32_t	nr,i;
	uint8_t *pbuf;
	//uint8_t key;
    //uint8_t i2ssavebuf;
  //uint8_t buff[100];

    pbuf=mymalloc(SRAMIN,AVI_VIDEO_BUF_SIZE);
    favi=(FIL*)mymalloc(SRAMIN,sizeof(FIL));
//	if(pbuf==NULL){
//		LCD_DisplayStringLine(Line2,(uint8_t*)"framebuf error!");
//		res=0xFF;
//	}
//
//	if(favi==NULL){
//		LCD_DisplayStringLine(Line3,(uint8_t*)"favi error!");
//		res=0xFF;
//	}

	while(res==0){
		res=f_open(favi,(char *)pname,FA_READ);
		if(res==0){

			printf("Open file %s\r\n",pname);

			//pbuf=framebuf;
			res=f_read(favi,pbuf,AVI_VIDEO_BUF_SIZE,(void *)&nr);
			if(res)
			{
				printf("fread error:%d\r\n",res);
				//LCD_DisplayStringLine(Line2,buff);
				break;
			}

            printf("avi init\r\n");
			res=avi_init(pbuf,AVI_VIDEO_BUF_SIZE);
			if(res)
			{
				printf("avi err:%d\r\n",res);
				//LCD_DisplayStringLine(Line2,buff);
				break;
			}

     // HAL_Delay(3000);
      LCD_Clear(LCD_COLOR_BLACK);
			//LCD_DisplayStringLine(0,"So far OK ");
			TIM6_Int_Init(avix.SecPerFrame/100-1,6000-1);
			offset=avi_srarch_id(pbuf,AVI_VIDEO_BUF_SIZE,(uint8_t*)"movi");
			//printf("avi offset %d\r\n",offset);
			avi_get_streaminfo(pbuf+offset+4);
			f_lseek(favi,offset+12);
			res=mjpegdec_init(avix.Width,avix.Height);
			//res=mjpegdec_init((lcddev.width-avix.Width)/2,110+(lcddev.height-110-avix.Height)/2);
			//LCD_SetCursor(0,0);
			//for(;;);
			playingtime=HAL_GetTick();
			while(1){
				if(avix.StreamID==AVI_VIDS_FLAG){
					//LCD_DisplayStringLine(0,(uint8_t*)"So far OK ");
					//pbuf=framebuf;
					Loop1:
					f_read(favi,pbuf,avix.StreamSize+8,(void *)&nr);
					//printf("%d pbuf ",nr);
					//for(i=0;i<avix.StreamSize+8;i++){
						//printf("%#02x, ",pbuf[i]);
					//}
					//printf("\r\n");
					res=mjpegdec_decode(pbuf,avix.StreamSize);
					if(res){
						//printf("Stream size %lu\r\n",avix.StreamSize);
						//LCD_DisplayStringLine(0,(uint8_t*)"decode error   !");
						//HAL_GPIO_TogglePin(LED2_GPIO_Port, LED2_Pin);
						//goto Loop1;
					}
					else{
						//printf("Stream size %lu\r\n",avix.StreamSize);
						//LCD_DisplayStringLine(0,(uint8_t*)"decode OK   !");
					}
					frameup=0;
					//HAL_GPIO_TogglePin(LED2_GPIO_Port, LED2_Pin);
					//HAL_GPIO_WritePin(LED2_GPIO_Port, LED2_Pin, GPIO_PIN_SET);
         //while(frameup==0);
         frameup=0;
         frame++;
         //HAL_GPIO_WritePin(LED2_GPIO_Port, LED2_Pin, GPIO_PIN_RESET);
				}
				else if(avix.StreamID==AVI_AUDS_FLAG){
					//video_time_show(favi,&avix);
					//printf("Stream size %lu\r\n",avix.StreamSize);
					//PC_Send(buff);
					f_read(favi,pbuf,avix.StreamSize+8,(void *)&nr);
					Karedox_VS1053_SDI_Write(pbuf,nr-8);
				}
				if(avi_get_streaminfo(pbuf+avix.StreamSize)){
					//LCD_DisplayStringLine(0,(uint8_t*)"frame error   !");
					//for(;;);
					break;
				}
			}
			//LCD_DisplayStringLine(0,"decode error   !");
			//for(;;);
		}
		else{
		LCD_DisplayStringLine(Line2,(uint8_t*)"Error Euy! ");
		TIM6->CR1&=~(1<<0);

		//f_close(favi);

		}
		res=1;
	}
	f_close(favi);
	printf("Play Finish\r\n");
	myfree(SRAMIN,pbuf);
	myfree(SRAMIN,favi);
	mjpegdec_free();

  return res;
}

void video_time_show(FIL *favi,AVI_INFO *aviinfo){

}




