/*
 * avi.h
 *
 *  Created on: Mar 31, 2018
 *      Author: Kang Usman
 */

#ifndef AVI_H_
#define AVI_H_

typedef enum {
	AVI_OK=0,
	AVI_RIFF_ERR,
	AVI_AVI_ERR,
	AVI_LIST_ERR,
	AVI_HDRL_ERR,
	AVI_AVIH_ERR,
	AVI_STRL_ERR,
	AVI_STRH_ERR,
	AVI_STRF_ERR,
	AVI_MOVI_ERR,
	AVI_FORMAT_ERR,
	AVI_STREAM_ERR,
}AVISTATUS;

#define AVI_RIFF_ID			0X46464952
#define AVI_AVI_ID			0X20495641
#define AVI_LIST_ID			0X5453494C
#define AVI_HDRL_ID			0X6C726468
#define AVI_MOVI_ID			0X69766F6D
#define AVI_STRL_ID			0X6C727473

#define AVI_AVIH_ID			0X68697661
#define AVI_STRH_ID			0X68727473
#define AVI_STRF_ID			0X66727473
#define AVI_STRD_ID			0X64727473

#define AVI_VIDS_STREAM		0X73646976
#define AVI_AUDS_STREAM		0X73647561


#define AVI_VIDS_FLAG		0X6463
#define AVI_AUDS_FLAG		0X7762
//////////////////////////////////////////////////////////////////////////////////////////

#define AVI_FORMAT_MJPG		0X47504A4D

typedef __packed struct{
	uint32_t SecPerFrame;
	uint32_t TotalFrame;
	uint32_t Width;
	uint32_t Height;
	uint32_t SampleRate;
	uint16_t Channels;
	uint16_t AudioBufSize;
	uint16_t AudioType;
	uint16_t StreamID;
	uint32_t StreamSize;
	uint8_t* VideoFLAG;
	uint8_t* AudioFLAG;
}AVI_INFO;

extern AVI_INFO avix;

typedef struct
{
	uint32_t RiffID;
	uint32_t FileSize;
	uint32_t AviID;
}AVI_HEADER;


typedef struct
{
	uint32_t FrameID;
	uint32_t FrameSize;
}FRAME_HEADER;



typedef struct
{
	uint32_t ListID;
	uint32_t BlockSize;
	uint32_t ListType;
}LIST_HEADER;

//avih �ӿ���Ϣ
typedef struct
{
	uint32_t BlockID;
	uint32_t BlockSize;
	uint32_t SecPerFrame;
	uint32_t MaxByteSec;
	uint32_t PaddingGranularity;
	uint32_t Flags;
	uint32_t TotalFrame;
	uint32_t InitFrames;
	uint32_t Streams;
	uint32_t RefBufSize;
	uint32_t Width;
	uint32_t Height;
	uint32_t Reserved[4];
}AVIH_HEADER;


typedef struct
{
	uint32_t BlockID;
	uint32_t BlockSize;
	uint32_t StreamType;
	uint32_t Handler;
	uint32_t Flags;
	uint16_t Priority;
	uint16_t Language;
	uint32_t InitFrames;
	uint32_t Scale;
	uint32_t Rate;
	uint32_t Start;
	uint32_t Length;
 	uint32_t RefBufSize;
    uint32_t Quality;
	uint32_t SampleSize;
	struct
	{
	   	short Left;
		short Top;
		short Right;
		short Bottom;
	}Frame;
}STRH_HEADER;


typedef struct
{
	uint32_t	 BmpSize;
 	long Width;
	long Height;
	uint16_t  Planes;
	uint16_t  BitCount;
	uint32_t  Compression;
	uint32_t  SizeImage;
	long XpixPerMeter;
	long YpixPerMeter;
	uint32_t  ClrUsed;
	uint32_t  ClrImportant;
}BMP_HEADER;


typedef struct
{
	uint8_t  rgbBlue;
	uint8_t  rgbGreen;
	uint8_t  rgbRed;
	uint8_t  rgbReserved;
}AVIRGBQUAD;


typedef struct
{
	uint32_t BlockID;
	uint32_t BlockSize;
	BMP_HEADER bmiHeader;
	AVIRGBQUAD bmColors[1];
}STRF_BMPHEADER;


typedef struct
{
	uint32_t BlockID;
	uint32_t BlockSize;
   	uint16_t FormatTag;
	uint16_t Channels;
	uint32_t SampleRate;
	uint32_t BaudRate;
	uint16_t BlockAlign;
	uint16_t Size;
}STRF_WAVHEADER;

#define	 MAKEWORD(ptr)	(uint16_t)(((uint16_t)*((uint8_t*)(ptr))<<8)|(uint16_t)*(uint8_t*)((ptr)+1))
#define  MAKEDWORD(ptr)	(uint32_t)(((uint16_t)*(uint8_t*)(ptr)|(((uint16_t)*(uint8_t*)(ptr+1))<<8)|\
						(((uint16_t)*(uint8_t*)(ptr+2))<<16)|(((uint16_t)*(uint8_t*)(ptr+3))<<24)))


AVISTATUS avi_init(uint8_t *buf,uint16_t size);
uint16_t avi_srarch_id(uint8_t* buf,uint16_t size,uint8_t* id);
AVISTATUS avi_get_streaminfo(uint8_t* buf);


uint8_t Avih_Parser(uint8_t *buffer);
uint8_t Strl_Parser(uint8_t *buffer);
uint8_t Strf_Parser(uint8_t *buffer);



uint16_t Search_Movi(uint8_t* buffer);
uint16_t Search_Fram(uint8_t* buffer);
uint32_t ReadUnit(uint8_t *buffer,uint8_t index,uint8_t Bytes,uint8_t Format);


#endif /* AVI_H_ */
