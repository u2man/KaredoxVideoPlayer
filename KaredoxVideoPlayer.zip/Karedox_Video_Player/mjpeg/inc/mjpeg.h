/*
 * mjpeg.h
 *
 *  Created on: Mar 31, 2018
 *      Author: Kang Usman
 */

#ifndef INC_MJPEG_H_
#define INC_MJPEG_H_

#include "stdio.h"
#include <cdjpeg.h>
//#include <sys.h>
#include <setjmp.h>


struct my_error_mgr {
  struct jpeg_error_mgr pub;
  jmp_buf setjmp_buffer;		//for return to caller
};
typedef struct my_error_mgr * my_error_ptr;

uint8_t mjpegdec_init(uint16_t offx,uint16_t offy);
void mjpegdec_free(void);
uint8_t mjpegdec_decode(uint8_t* buf,uint32_t bsize);

#endif /* INC_MJPEG_H_ */
