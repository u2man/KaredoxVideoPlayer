/*
 * avi.c
 *
 *  Created on: Mar 31, 2018
 *      Author: Kang Usman
 */


#include "global.h"

AVI_INFO avix;
uint8_t*const AVI_VIDS_FLAG_TBL[2]={"00dc","01dc"};
uint8_t*const AVI_AUDS_FLAG_TBL[2]={"00wb","01wb"};

AVISTATUS avi_init(uint8_t *buf,uint16_t size)
{
	uint16_t offset;
	uint8_t *tbuf;
	uint8_t tbuf1[128];
	AVISTATUS res=AVI_OK;
	AVI_HEADER *aviheader;
	LIST_HEADER *listheader;
	AVIH_HEADER *avihheader;
	STRH_HEADER *strhheader;

	STRF_BMPHEADER *bmpheader;
	STRF_WAVHEADER *wavheader;

	tbuf=buf;
	aviheader=(AVI_HEADER*)buf;
	if(aviheader->RiffID!=AVI_RIFF_ID)return AVI_RIFF_ERR;
	if(aviheader->AviID!=AVI_AVI_ID)return AVI_AVI_ERR;
	buf+=sizeof(AVI_HEADER);
	listheader=(LIST_HEADER*)(buf);
	if(listheader->ListID!=AVI_LIST_ID)return AVI_LIST_ERR;
	if(listheader->ListType!=AVI_HDRL_ID)return AVI_HDRL_ERR;
	buf+=sizeof(LIST_HEADER);
	avihheader=(AVIH_HEADER*)(buf);
	if(avihheader->BlockID!=AVI_AVIH_ID)return AVI_AVIH_ERR;
	avix.SecPerFrame=avihheader->SecPerFrame;
	avix.TotalFrame=avihheader->TotalFrame;
	buf+=avihheader->BlockSize+8;
	listheader=(LIST_HEADER*)(buf);
	if(listheader->ListID!=AVI_LIST_ID)return AVI_LIST_ERR;
	if(listheader->ListType!=AVI_STRL_ID)return AVI_STRL_ERR;
	strhheader=(STRH_HEADER*)(buf+12);
	if(strhheader->BlockID!=AVI_STRH_ID)return AVI_STRH_ERR;
 	if(strhheader->StreamType==AVI_VIDS_STREAM)
	{
		if(strhheader->Handler!=AVI_FORMAT_MJPG)return AVI_FORMAT_ERR;
		avix.VideoFLAG=(uint8_t*)AVI_VIDS_FLAG_TBL[0];
		avix.AudioFLAG=(uint8_t*)AVI_AUDS_FLAG_TBL[1];
		bmpheader=(STRF_BMPHEADER*)(buf+12+strhheader->BlockSize+8);
		if(bmpheader->BlockID!=AVI_STRF_ID)return AVI_STRF_ERR;
		avix.Width=bmpheader->bmiHeader.Width;
		avix.Height=bmpheader->bmiHeader.Height;
		buf+=listheader->BlockSize+8;
		listheader=(LIST_HEADER*)(buf);
		if(listheader->ListID!=AVI_LIST_ID)
		{
			avix.SampleRate=0;
			avix.Channels=0;
			avix.AudioType=0;

		}else
		{
			if(listheader->ListType!=AVI_STRL_ID)return AVI_STRL_ERR;
			strhheader=(STRH_HEADER*)(buf+12);
			if(strhheader->BlockID!=AVI_STRH_ID)return AVI_STRH_ERR;
			if(strhheader->StreamType!=AVI_AUDS_STREAM)return AVI_FORMAT_ERR;
			wavheader=(STRF_WAVHEADER*)(buf+12+strhheader->BlockSize+8);
			if(wavheader->BlockID!=AVI_STRF_ID)return AVI_STRF_ERR;
			avix.SampleRate=wavheader->SampleRate;
			avix.Channels=wavheader->Channels;
			avix.AudioType=wavheader->FormatTag;
		}
	}else if(strhheader->StreamType==AVI_AUDS_STREAM)
	{
		avix.VideoFLAG=(uint8_t*)AVI_VIDS_FLAG_TBL[1];
		avix.AudioFLAG=(uint8_t*)AVI_AUDS_FLAG_TBL[0];
		wavheader=(STRF_WAVHEADER*)(buf+12+strhheader->BlockSize+8);
		if(wavheader->BlockID!=AVI_STRF_ID)return AVI_STRF_ERR;
		avix.SampleRate=wavheader->SampleRate;
		avix.Channels=wavheader->Channels;
		avix.AudioType=wavheader->FormatTag;
		buf+=listheader->BlockSize+8;
		listheader=(LIST_HEADER*)(buf);
		if(listheader->ListID!=AVI_LIST_ID)return AVI_LIST_ERR;
		if(listheader->ListType!=AVI_STRL_ID)return AVI_STRL_ERR;
		strhheader=(STRH_HEADER*)(buf+12);
		if(strhheader->BlockID!=AVI_STRH_ID)return AVI_STRH_ERR;
		if(strhheader->StreamType!=AVI_VIDS_STREAM)return AVI_FORMAT_ERR;
		bmpheader=(STRF_BMPHEADER*)(buf+12+strhheader->BlockSize+8);
		if(bmpheader->BlockID!=AVI_STRF_ID)return AVI_STRF_ERR;
		if(bmpheader->bmiHeader.Compression!=AVI_FORMAT_MJPG)return AVI_FORMAT_ERR;
		avix.Width=bmpheader->bmiHeader.Width;
		avix.Height=bmpheader->bmiHeader.Height;
	}
	offset=avi_srarch_id(tbuf,size,"movi");
	if(offset==0)return AVI_MOVI_ERR;
	if(avix.SampleRate)//����Ƶ��,�Ų���
	{
		tbuf+=offset;
		offset=avi_srarch_id(tbuf,size,avix.AudioFLAG);
		if(offset==0)return AVI_STREAM_ERR;
		tbuf+=offset+4;
		avix.AudioBufSize=*((uint16_t*)tbuf);
	}
//	return res;
	printf("avi init ok\r\n");
	//LCD_Clear(LCD_COLOR_BLUE);
	//LCD_DEFAULT_FONT=Font12x12;
//	LCD_DisplayStringLine(Line0,(uint8_t*)"AVI init OK");
   printf("avix.SecPerFrame:%d\r\n",avix.SecPerFrame);
//	LCD_DisplayStringLine(Line1,tbuf1);
   printf("avix.TotalFrame:%d\r\n",avix.TotalFrame);
//	LCD_DisplayStringLine(Line2,tbuf1);
   printf("avix.Width:%d\r\n",avix.Width);
//	LCD_DisplayStringLine(Line3,tbuf1);
   printf("avix.Height:%d\r\n",avix.Height);
//	LCD_DisplayStringLine(Line4,tbuf1);
	if(avix.AudioType==0x55)
	  printf("avix.AudioType:MP3\r\n");
	if(avix.AudioType==0x01)
	  printf("avix.AudioType:PCM\r\n");
//
//	LCD_DisplayStringLine(Line5,tbuf1);
	printf("avix.SampleRate:%d\r\n",avix.SampleRate);
//	LCD_DisplayStringLine(Line6,tbuf1);
	printf("avix.Channels:%d\r\n",avix.Channels);
//	LCD_DisplayStringLine(Line7,tbuf1);
	printf("avix.AudioBufSize:%d\r\n",avix.AudioBufSize);
//	LCD_DisplayStringLine(Line8,tbuf1);
	printf("avix.VideoFLAG:%s\r\n",avix.VideoFLAG);
//	LCD_DisplayStringLine(Line9,tbuf1);
	printf("avix.AudioFLAG:%s\r\n",avix.AudioFLAG);
//	LCD_DisplayStringLine(Line10,tbuf1);
	return res;
}

uint16_t avi_srarch_id(uint8_t* buf,uint16_t size,uint8_t *id)
{
	uint16_t i;
	size-=4;
	for(i=0;i<size;i++)
	{
	   	if(buf[i]==id[0])
			if(buf[i+1]==id[1])
				if(buf[i+2]==id[2])
					if(buf[i+3]==id[3])return i;
	}
	return 0;
}

AVISTATUS avi_get_streaminfo(uint8_t* buf)
{
	avix.StreamID=MAKEWORD(buf+2);
	avix.StreamSize=MAKEDWORD(buf+4);
	if(avix.StreamSize%2)avix.StreamSize++;
	if(avix.StreamID==AVI_VIDS_FLAG||avix.StreamID==AVI_AUDS_FLAG){
		//printf("AVI OK\r\n");
		return AVI_OK;
	}
	return AVI_STREAM_ERR;
}
