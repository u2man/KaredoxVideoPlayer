/*
 * mjpeg.c
 *
 *  Created on: Mar 31, 2018
 *      Author: Kang Usman
 */

#include "global.h"
#include "jpeglib.h"

#define MJPEG_MAX_MALLOC_SIZE 		38*1024

struct jpeg_decompress_struct *cinfo;
struct my_error_mgr *jerr;
uint8_t *jpegbuf;//[MJPEG_MAX_MALLOC_SIZE];
uint32_t jbufsize;
uint16_t imgoffx,imgoffy;

uint8_t *jmembuf;//[MJPEG_MAX_MALLOC_SIZE];
uint32_t jmempos;

void* mjpeg_malloc(uint32_t num)
{
	uint32_t curpos=jmempos;
 	jmempos+=num;
	if(jmempos>38*1024)
	{
		//printf("mem error:%d,%d",curpos,num);
	}
	return (void *)&jmembuf[curpos];
}

static void my_error_exit(j_common_ptr cinfo)
{
	my_error_ptr myerr=(my_error_ptr) cinfo->err;
	(*cinfo->err->output_message) (cinfo);
	longjmp(myerr->setjmp_buffer, 1);
}

METHODDEF(void) my_emit_message(j_common_ptr cinfo, int msg_level)
{
	my_error_ptr myerr=(my_error_ptr) cinfo->err;
    if(msg_level<0)
	{
		//printf("emit msg:%d\r\n",msg_level);
		longjmp(myerr->setjmp_buffer, 1);
	}
}


static void init_source(j_decompress_ptr cinfo)
{

    return;
}

static boolean fill_input_buffer(j_decompress_ptr cinfo)
{
	int i;

//	printf("jbufsize %lu ",jbufsize);
//	for(i=0;i<16;i++){
//		printf("%#02X, ",jpegbuf[i]);
//	}
//	printf("\r\n");
	if(jbufsize==0)
	{
		//printf("jd read off\r\n");

        jpegbuf[0] = (uint8_t) 0xFF;
        jpegbuf[1] = (uint8_t) JPEG_EOI;
  		cinfo->src->next_input_byte =jpegbuf;
		cinfo->src->bytes_in_buffer = 2;
	}else
	{
		cinfo->src->next_input_byte =jpegbuf;
		cinfo->src->bytes_in_buffer = jbufsize;
		jbufsize-=jbufsize;
	}
    return TRUE;
}

static void skip_input_data(j_decompress_ptr cinfo, long num_bytes)
{
    /* Just a dumb implementation for now.  Could use fseek() except
    * it doesn't work on pipes.  Not clear that being smart is worth
    * any trouble anyway --- large skips are infrequent.
    */
    if (num_bytes > 0)
    {
        while(num_bytes>(long) cinfo->src->bytes_in_buffer)
        {
            num_bytes-=(long)cinfo->src->bytes_in_buffer;
            (void)cinfo->src->fill_input_buffer(cinfo);
            /* note we assume that fill_input_buffer will never
            * return FALSE, so suspension need not be handled.
            */
        }
        cinfo->src->next_input_byte += (size_t) num_bytes;
        cinfo->src->bytes_in_buffer -= (size_t) num_bytes;
    }
}

static void term_source(j_decompress_ptr cinfo)
{

    return;
}

static void jpeg_filerw_src_init(j_decompress_ptr cinfo)
{
    if (cinfo->src == NULL)     /* first time for this JPEG object? */
    {
        cinfo->src = (struct jpeg_source_mgr *)
                     (*cinfo->mem->alloc_small)((j_common_ptr) cinfo, JPOOL_PERMANENT,
                                              sizeof(struct jpeg_source_mgr));
    }
    cinfo->src->init_source = init_source;
    cinfo->src->fill_input_buffer = fill_input_buffer;
    cinfo->src->skip_input_data = skip_input_data;
    cinfo->src->resync_to_restart = jpeg_resync_to_restart; /* use default method */
    cinfo->src->term_source = term_source;
    cinfo->src->bytes_in_buffer = 0; /* forces fill_input_buffer on first read */
    cinfo->src->next_input_byte = NULL; /* until buffer loaded */
}

uint8_t mjpegdec_init(uint16_t offx,uint16_t offy){

	cinfo=mymalloc(SRAMIN,sizeof(struct jpeg_decompress_struct));
	jerr=mymalloc(SRAMIN,sizeof(struct my_error_mgr));
	jmembuf=mymalloc(SRAMIN,MJPEG_MAX_MALLOC_SIZE);
	jpegbuf=mymalloc(SRAMIN,MJPEG_MAX_MALLOC_SIZE);

	if(jmembuf==0)
	{
      mjpegdec_free();
		  LCD_DisplayStringLine(Line3,(uint8_t*)"jmembuf mem alloc error!");
		  return 1;
	}

	imgoffx=offx;
	imgoffy=offy;
	return 0;

}

void mjpegdec_free(void){
	myfree(SRAMIN,cinfo);
	myfree(SRAMIN,jerr);
	myfree(SRAMIN,jmembuf);

}

uint8_t mjpegdec_decode(uint8_t* buf,uint32_t bsize){
	   JSAMPARRAY buffer;
		if(bsize==0)return 1;
		jpegbuf=buf;
		jbufsize=bsize;
		jmempos=0;//MJEPG����,���´�0��ʼ�����ڴ�

		cinfo->err=jpeg_std_error(&jerr->pub);
		jerr->pub.error_exit = my_error_exit;
		jerr->pub.emit_message = my_emit_message;
		//if(bsize>20*1024)printf("s:%d\r\n",bsize);
		if (setjmp(jerr->setjmp_buffer)) //������
		{
	 		jpeg_abort_decompress(cinfo);
			jpeg_destroy_decompress(cinfo);
			printf("Abort compression\r\n");
			//for(;;);
			return 2;
		}
		jpeg_create_decompress(cinfo);
		jpeg_filerw_src_init(cinfo);
		jpeg_read_header(cinfo, TRUE);
		cinfo->dct_method = JDCT_IFAST;
		cinfo->do_fancy_upsampling = 0;
		jpeg_start_decompress(cinfo);
		LCD_SetDisplayWindow(0,0,cinfo->output_height,cinfo->output_width);
	//	LCD_SetDisplayWindow
		LCD_SetCursor(0,0);
		LCD_WriteRAM_Prepare();     		//��ʼд��GRAM
		while (cinfo->output_scanline < cinfo->output_height)
		{
			jpeg_read_scanlines(cinfo, buffer, 1);
		}
		LCD_SetDisplayWindow(0,0,240,320);//�ָ�����
		jpeg_finish_decompress(cinfo);
		jpeg_destroy_decompress(cinfo);
	return 0;
}
